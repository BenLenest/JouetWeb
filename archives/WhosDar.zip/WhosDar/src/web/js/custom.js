var ajax;

$("a#subscribeLink").click(function(e) {
    $("div#loginDiv").hide();
    $("div#subscribeDiv").show();
    return false;
});

$("a#loginLink").click(function(e) {
    $("div#subscribeDiv").hide();
    $("div#loginDiv").show();
    return false;
});

$("form#ajaxLogin").submit(function(e) {

    e.preventDefault();

    var email = $("#emailLogin").val();
    var password = $("#passwordLogin").val();

    if (ajax && ajax.readyState !== 4) { ajax.abort(); }

    ajax = $.ajax({
        type: "POST",
        url: "http://localhost:8080/whosdar/app/login",
        async: false,
        timeout: 15000,
        dataType: "html",
        contentType: "text/html",
        data: { email : email, password : password },
        success: function(data) {
            var returned = jQuery.parseJSON(data);
            if (returned.result == "true") {
                $("#loginFailure").hide();
                window.location.replace("http://localhost:8080/whosdar/app/index");
            }
            else if (returned.result == "false") {
                $("#loginFailure").show();
            }
        }
    });

    return false;
});

$("form#ajaxSubscribe").submit(function(e) {

    e.preventDefault();

    var firstName = $("#firstNameSubscribe").val();
    var lastName = $("#lastNameSubscribe").val();
    var street = $("#streetSubscribe").val();
    var zipCode = $("#zipCodeSubscribe").val();
    var city = $("#citySubscribe").val();
    var country = $("#countrySubscribe").val();
    var email = $("#emailSubscribe").val();
    var password = $("#passwordSubscribe").val();

    if (ajax && ajax.readyState !== 4) { ajax.abort(); }

    ajax = $.ajax({
        type: "POST",
        url: "http://localhost:8080/whosdar/app/subscribe",
        async: false,
        timeout: 15000,
        dataType: "html",
        contentType: "text/html",
        data: { firstName : firstName,
                lastName : lastName,
                street : street,
                zipCode : zipCode,
                city : city,
                country : country,
                email : email,
                password : password },
        success: function(data) {
            var returned = jQuery.parseJSON(data);
            if (returned.result == "true") {
                $("#subscribeFailure").hide();
                window.location.replace("http://localhost:8080/whosdar/app/index");
            }
            else if (returned.result == "false") {
                $("#subscribeFailure").show();
            }
        }
    });

    return false;
});

$("div.menu button#availability").click(function(e) {
    window.location.replace("http://localhost:8080/whosdar/app/index");
    return false;
});

$("div.menu button#profile").click(function(e) {
    window.location.replace("http://localhost:8080/whosdar/app/me");
    return false;
});

$("div.menu button#logout").click(function(e) {

    if (ajax && ajax.readyState !== 4) { ajax.abort(); }

    ajax = $.ajax({
        type: "POST",
        url: "http://localhost:8080/whosdar/app/logout",
        async: false,
        timeout : 15000,
        dataType: "html",
        contentType: "text/html",
        success: function(data) {
            window.location.replace("http://localhost:8080/whosdar/app/login");
        }
    });

    return false;
});