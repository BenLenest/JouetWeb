package model;

public class Address {

    /* ATTRIBUTES ========================================================== */

    private String street;
    private int zipCode;
    private String city;
    private String country;

    /* CONSTRUCTOR ========================================================= */

    public Address(String street, int zipCode, String city, String country) {
        this.street = street;
        this.zipCode = zipCode;
        this.city = city;
        this.country = country;
    }

    /* SETTERS ============================================================= */

    public void setStreet(String street) {
        this.street = street;
    }

    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    /* GETTERS ============================================================= */

    public String getStreet() {
        return street;
    }

    public int getZipCode() {
        return zipCode;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }
}
