package manager;

import model.Request;
import model.Response;
import model.User;
import model.enums.EnumContentType;
import org.json.JSONObject;
import tools.Utils;

import java.util.List;
import java.util.stream.Collectors;

public class ApiController {

    /* GET METHODS ========================================================= */

    public static Response getAllUsers(Request request) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("users", ApplicationController.users);
        response.setByteContent(jsonObject.toString().getBytes());
        return response;
    }

    public static Response getAvailableUsers(Request request) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        List<User> availableUsers = ApplicationController.users.values().stream().filter(user -> user.isAvailable()).collect(Collectors.toList());
        JSONObject jsonObject = Utils.buildJsonList("online", availableUsers);
        response.setByteContent(jsonObject.toString().getBytes());
        return response;
    }

    public static Response getUnavailableUsers(Request request) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        List<User> unavailableUsers = ApplicationController.users.values().stream().filter(user -> !user.isAvailable()).collect(Collectors.toList());
        JSONObject jsonObject = Utils.buildJsonList("offline", unavailableUsers);
        response.setByteContent(jsonObject.toString().getBytes());
        return response;
    }
}
