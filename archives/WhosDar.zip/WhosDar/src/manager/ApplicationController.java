package manager;

import model.Address;
import model.Request;
import model.Response;
import model.User;
import model.enums.EnumContentType;
import org.json.JSONObject;
import tools.Constants;
import tools.Utils;
import tools.WebTemplate;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ApplicationController {

    /* DATABASE (simulation) =============================================== */

    private static int usersIdCounter = 5;
    public static Map<String, User> users = new LinkedHashMap<String, User>() {{
        put("NicolasTelera", new User(0, "Nicolas", "Telera", new Address("9 rue Fragonard", 94410, "Saint-Maurice", "France"), "nicolas.telera@gmail.com", "nico", false));
        put("BenjaminLeNestour", new User(1, "Benjamin", "Le Nestour", new Address("3 rue des Mahiettes", 91800, "Brunoy", "France"), "benjamin.lenestour@gmail.com", "ben", true));
        put("MickaelTabosa", new User(2, "Mickaël", "Tabosa", new Address("5 rue du Chou", 75005, "Paris", "France"), "mickael.tabosa@gmail.com", "mika", false));
        put("JordhanLeoture", new User(3, "Jordhan", "Leoture", new Address("17 impasse universitaire", 75008, "Paris", "France"), "jordhan.leoture@gmail.com", "jor", false));
        put("MaximeBonnet", new User(4, "Maxime", "Bonnet", new Address("25 bis rue de la cagoule", 92040, "Issy les Moulineaux", "France"), "maxime.bonnet@gmail.com", "max", true));
    }};

    /* CONSTANTS =========================================================== */

    private static final String TEMPLATE_INDEX = "index.html";
    private static final String TEMPLATE_ME = "me.html";
    private static final String TEMPLATE_USER = "user.html";
    private static final String TEMPLATE_USER_TABLE = "users_table.html";
    private static final String TEMPLATE_USER_TABLE_LINE = "user_table_line.html";

    /* GET METHODS ========================================================= */

    public static Response getIndexView(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (request.getSession() != null) {
            response.setSession(request.getSession());

            ClassLoader loader = ApplicationController.class.getClassLoader();
            StringBuilder builder = new StringBuilder();
            Map<String, String> values = new HashMap<>();
            WebTemplate template = null;

            for (User user : users.values()) {
                values.clear();

                values.put("firstName", user.getFirstName());
                values.put("lastName", user.getLastName());
                values.put("name_url", Utils.generateUserKey(user));
                values.put("status", user.isAvailable() ? "disponible" : "non disponible");
                template = new WebTemplate(TEMPLATE_USER_TABLE_LINE, values);
                builder.append(template.generateContent(loader));
            }

            values.clear();
            values.put("users_lines", builder.toString());
            template = new WebTemplate(TEMPLATE_USER_TABLE, values);
            String table = template.generateContent(loader);

            values.clear();
            values.put("users_table", table);
            template = new WebTemplate(TEMPLATE_INDEX, values);

            response.setContent(template.generateContent(loader));
        } else {
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        }

        return response;
    }

    public static Response getUserView(Request request, String name) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (request.getSession() != null) {
            response.setSession(request.getSession());
            User user = users.get(name);
            Map<String, String> values = new HashMap<>();
            values.put("title", user.getFirstName() + " " + user.getLastName());
            values.put("name", user.getFirstName() + " " + user.getLastName());
            values.put("street", user.getAddress().getStreet());
            values.put("zipCode", String.valueOf(user.getAddress().getZipCode()));
            values.put("city", user.getAddress().getCity());
            values.put("country", user.getAddress().getCountry());
            values.put("email", user.getEmail());
            values.put("available", user.isAvailable() ? "Oui" : "Non");
            WebTemplate template = new WebTemplate(TEMPLATE_USER, values);
            response.setContent(template.generateContent(ApplicationController.class.getClassLoader()));
        } else {
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        }
        return response;
    }

    public static Response getMyView(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (request.getSession() != null) {
            response.setSession(request.getSession());
            System.out.println(request.getSession().getValues().get(User.SESSION_USER_ID));
            User user = users.get(request.getSession().getValues().get(User.SESSION_USER_ID));
            Map<String, String> values = new HashMap<>();
            values.put("name", user.getFirstName() + " " + user.getLastName());
            values.put("street", user.getAddress().getStreet());
            values.put("zipCode", String.valueOf(user.getAddress().getZipCode()));
            values.put("city", user.getAddress().getCity());
            values.put("country", user.getAddress().getCountry());
            values.put("email", user.getEmail());
            WebTemplate template = new WebTemplate(TEMPLATE_ME, values);
            response.setContent(template.generateContent(ApplicationController.class.getClassLoader()));
        } else {
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        }
        return response;
    }

    /* POST METHODS ======================================================== */

    public static Response subscribe(Request request, String firstName, String lastName, String street, int zipCode, String city, String country, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        Address address = new Address(street, zipCode, city, country);
        User user = new User(usersIdCounter++, firstName, lastName, address, email, password, false);
        users.put(Utils.generateUserKey(user), user);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("result", "true");
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        response.setContent(jsonObject.toString());
        response.setSession(Utils.generateSession(request, Utils.generateUserKey(user)));
        return response;
    }

    public static Response login(Request request, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        boolean success = false;
        String userId = null;
        for (User user : users.values()) {
            if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                userId = Utils.generateUserKey(user);
                success = true;
                break;
            }
        }
        JSONObject jsonObject = new JSONObject();
        if (success) {
            jsonObject.put("result", "true");
            response.setSession(Utils.generateSession(request, userId));
        }
        else jsonObject.put("result", "false");
        response.setContent(jsonObject.toString());
        return response;
    }

    public static Response logout(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        response.setSession(null);
        return response;
    }
}
