package manager;

import model.Response;
import model.Session;
import model.User;
import model.enums.EnumContentType;
import org.json.JSONObject;
import tools.Constants;
import tools.Utils;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ResourcesController {

    /* DATABASE (simulation) =============================================== */

    /**
     * Ici, les mots de passe sont volontairement non sécurisés dans la mesure
     * où cette application n'est qu'un exemple d'utilisation des session.
     * Le côté sécurité sera plus exploité dans l'application finale.
     */

    private static int idCounter = 2;
    private static List<User> users = new ArrayList<User>() {{
        add(new User(0, "nicolas.telera@gmail.com", "nico"));
        add(new User(1, "benjamin.lenestour@gmail.com", "ben"));
    }};

    /* GET METHODS ========================================================= */

    public static Response getIndexView(Session session) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (session.getValues().containsKey(Constants.COOKIE_LOGGED_IN))
            response.setContent(Utils.readHtmlFile(Constants.FILE_INDEX));
        else
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        return Utils.buildResponseWithSession(response, session);
    }

    /* POST METHODS ======================================================== */

    public static Response subscribe(Session session, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        User user = new User(idCounter++, email, password);
        users.add(user);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("result", "true");
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        response.setSession(Utils.updateSessionWithLoggedInfo(session));
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, session);
    }

    public static Response login(Session session, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        boolean success = false;
        for (User user : users) {
            if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                session = Utils.updateSessionWithLoggedInfo(session);
                success = true;
                break;
            }
        }
        JSONObject jsonObject = new JSONObject();
        if (success) jsonObject.put("result", "true");
        else jsonObject.put("result", "false");
        response.setSession(session);
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, session);
    }

    public static Response logout(Session session) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        response.setSession(session);
        session.getValues().remove(Constants.COOKIE_LOGGED_IN);
        return Utils.buildResponseWithSession(response, session);
    }
}
