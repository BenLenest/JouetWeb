package manager;

import model.Request;
import model.Response;
import model.User;
import model.enums.EnumContentType;
import org.json.JSONObject;
import tools.Constants;
import tools.Utils;

import java.util.*;

public class ResourcesController {

    /* DATABASE (simulation) =============================================== */

    /**
     * Ici, les mots de passe sont volontairement non sécurisés dans la mesure
     * où cette application n'est qu'un exemple d'utilisation des session.
     * Le côté sécurité sera plus exploité dans l'application finale.
     */

    private static int idCounter = 2;
    private static List<User> users = new ArrayList<User>() {{
        add(new User(0, "nicolas.telera@gmail.com", "nico"));
        add(new User(1, "benjamin.lenestour@gmail.com", "ben"));
    }};

    /* GET METHODS ========================================================= */

    public static Response getIndexView(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (request.getSession() != null)
            response.setContent(Utils.readHtmlFile(Constants.FILE_INDEX));
        else
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        return response;
    }

    /* POST METHODS ======================================================== */

    public static Response subscribe(Request request, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        User user = new User(idCounter++, email, password);
        users.add(user);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("result", "true");
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        response.setContent(jsonObject.toString());
        response.setSession(Utils.generateSession(request));
        return response;
    }

    public static Response login(Request request, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        boolean success = false;
        for (User user : users) {
            if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                success = true;
                break;
            }
        }
        JSONObject jsonObject = new JSONObject();
        if (success) {
            jsonObject.put("result", "true");
            response.setSession(Utils.generateSession(request));
        }
        else jsonObject.put("result", "false");
        response.setContent(jsonObject.toString());
        return response;
    }

    public static Response logout(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        request.setSession(null);
        return response;
    }
}
