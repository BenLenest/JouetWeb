package manager;

import model.Response;
import model.Session;
import model.enums.EnumContentType;
import tools.Constants;
import tools.Utils;

public class ResourcesController {

    /* GET METHODS ========================================================= */

    public static Response getIndexView(Session session) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_INDEX));
        return Utils.buildResponseWithSession(response, session);
    }

    /* POST METHODS ======================================================== */

}
