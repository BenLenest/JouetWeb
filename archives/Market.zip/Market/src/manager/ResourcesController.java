package manager;

import model.Response;
import model.Session;
import model.User;
import model.enums.EnumContentType;
import tools.Constants;
import tools.Utils;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class ResourcesController {

    /* DATABASE (simulation) =============================================== */

    private static int idCounter = 2;
    private static List<User> users = new ArrayList<User>() {{
        add(new User(0, "nicolas.telera@gmail.com", "nico"));
        add(new User(1, "benjamin.lenestour@gmail.com", "ben"));
    }};

    /* GET METHODS ========================================================= */

    public static Response getIndexView(Session session) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (session.getValues().containsKey(Constants.COOKIE_LOGGED_IN))
            response.setContent(Utils.readHtmlFile(Constants.FILE_INDEX));
        else
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        return Utils.buildResponseWithSession(response, session);
    }

    /* POST METHODS ======================================================== */

    public static Response login(Session session, String email, String password) {
        try {
            email = java.net.URLDecoder.decode(email, StandardCharsets.UTF_8.name());
            password = java.net.URLDecoder.decode(password, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        for (User user : users) {
            if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                session.getValues().put(Constants.COOKIE_LOGGED_IN, "true");
                response.setSession(session);
                response.setContent(Utils.readHtmlFile(Constants.FILE_INDEX));
            }
        }
        return Utils.buildResponseWithSession(response, session);
    }

    public static Response logout(Session session) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        response.setSession(session);
        session.getValues().remove(Constants.COOKIE_LOGGED_IN);
        return Utils.buildResponseWithSession(response, session);
    }
}
