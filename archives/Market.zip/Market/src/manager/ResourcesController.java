package manager;

import model.Game;
import model.Request;
import model.Response;
import model.User;
import model.enums.EnumContentType;
import org.json.JSONObject;
import tools.Constants;
import tools.Utils;
import tools.WebTemplate;

import java.util.*;

public class ResourcesController {

    /* DATABASE (simulation) =============================================== */

    /**
     * Ici, les mots de passe sont volontairement non sécurisés dans la mesure
     * où cette application n'est qu'un exemple d'utilisation des session.
     * Le côté sécurité sera plus exploité dans l'application finale.
     */

    private static int userIdCounter = 2;
    private static Map<Integer, User> users = new HashMap<Integer, User>() {{
        put(0, new User(0, "nicolas.telera@gmail.com", "nico"));
        put(1, new User(1, "benjamin.lenestour@gmail.com", "ben"));
    }};
    private static Map<String, Game> games = new HashMap<String, Game>() {{
        put("Skyrim", new Game(0, "Skyrim", 2011, "RPG", "Bethesda Softworks", 49.99, "The Elder Scrolls V : Skyrim est le cinquième épisode de la saga de jeux de rôle du même nom. Le scénario se passe 200 ans après l'histoire du quatrième opus, quand Alduin fait son retour au milieu d'une guerre civile. Seul le Dovahkiin, incarné par le joueur, peut mettre un terme à cette sombre affaire... Un monde gigantesque empli de quêtes est à explorer et auquel se sont rajoutées des extensions débloquant plus de quêtes."));
        put("SuperSmashBros", new Game(1, "Super Smash Bros", 2014, "Combat", "Nintendo", 29.99, "Red Dead Redemption est un jeu d'action en monde ouvert qui se déroule au début du XXème siècle. Pendant la révolution mexicaine, le joueur incarne John Marston, ex-hors-la-loi devant traquer ses anciens camarades l'ayant laissé pour mort. Il devra accomplir de nombreuses missions pour obtenir son indépendance."));
        put("ShadowWarrior", new Game(2, "Shadow Warrior", 2013, "FPS", "Devolver Digital", 15.00, "Shadow Warrior sur PC est un FPS, reboot du même titre sorti en 1997. Dans le rôle de Lo Wang, emparez-vous d\'un katana légendaire et repoussez une invasion de démons. Nerveux et bourrin, Shadow Warrior est un FPS défouloir et old-school en solo."));
        put("RedDeadRedemption", new Game(3, "Red Dead Redemption", 2010, "Action", "Rockstar Games", 39.99, "Red Dead Redemption est un jeu d'action en monde ouvert qui se déroule au début du XXème siècle. Pendant la révolution mexicaine, le joueur incarne John Marston, ex-hors-la-loi devant traquer ses anciens camarades l'ayant laissé pour mort. Il devra accomplir de nombreuses missions pour obtenir son indépendance."));
    }};

    /* CONSTANTS =========================================================== */

    private static final String TEMPLATE_INDEX = "index.html";
    private static final String TEMPLATE_GAME = "game.html";
    private static final String TEMPLATE_GAME_TABLE = "game_table.html";
    private static final String TEMPLATE_GAME_TABLE_LINE = "game_table_line.html";

    /* GET METHODS ========================================================= */

    public static Response getIndexView(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (request.getSession() != null) {
            response.setSession(request.getSession());

            ClassLoader loader = ResourcesController.class.getClassLoader();
            StringBuilder builder = new StringBuilder();
            Map<String, String> values = new HashMap<>();
            WebTemplate template = null;

            for (Game game : games.values()) {
                values.clear();
                values.put("name", game.getName());
                values.put("name_url", game.getName().replace(" ", ""));
                values.put("price", String.valueOf(game.getPrice()));
                template = new WebTemplate(TEMPLATE_GAME_TABLE_LINE, values);
                builder.append(template.generateContent(loader));
            }

            values.clear();
            values.put("games_lines", builder.toString());
            template = new WebTemplate(TEMPLATE_GAME_TABLE, values);
            String table = template.generateContent(loader);

            values.clear();
            values.put("games_table", table);
            template = new WebTemplate(TEMPLATE_INDEX, values);

            response.setContent(template.generateContent(loader));
        } else {
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        }
        return response;
    }

    public static Response getGameView(Request request, String id) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        if (request.getSession() != null) {
            response.setSession(request.getSession());
            Game game = games.get(id);
            Map<String, String> values = new HashMap<>();
            values.put("title", game.getName());
            values.put("description", game.getDescription());
            values.put("name", game.getName());
            values.put("year", String.valueOf(game.getYear()));
            values.put("type", game.getType());
            values.put("editor", game.getEditor());
            values.put("price", String.valueOf(game.getPrice()));
            WebTemplate template = new WebTemplate(TEMPLATE_GAME, values);
            response.setContent(template.generateContent(ResourcesController.class.getClassLoader()));
        } else {
            response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        }
        return response;
    }

    /* POST METHODS ======================================================== */

    public static Response subscribe(Request request, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        User user = new User(userIdCounter, email, password);
        users.put(userIdCounter++, user);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("result", "true");
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        response.setContent(jsonObject.toString());
        response.setSession(Utils.generateSession(request, user.getId()));
        return response;
    }

    public static Response login(Request request, String email, String password) {
        email = Utils.decodeUrlParameter(email);
        password = Utils.decodeUrlParameter(password);
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        boolean success = false;
        int id = 0;
        for (User user : users.values()) {
            if (email.equals(user.getEmail()) && password.equals(user.getPassword())) {
                id = user.getId();
                success = true;
                break;
            }
        }
        JSONObject jsonObject = new JSONObject();
        if (success) {
            jsonObject.put("result", "true");
            response.setSession(Utils.generateSession(request, id));
        }
        else jsonObject.put("result", "false");
        response.setContent(jsonObject.toString());
        return response;
    }

    public static Response logout(Request request) {
        Response response = Utils.buildResponse(EnumContentType.TEXT_HTML);
        response.setContent(Utils.readHtmlFile(Constants.FILE_LOGIN));
        response.setSession(null);
        return response;
    }
}
