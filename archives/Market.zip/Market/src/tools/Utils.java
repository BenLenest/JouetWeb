package tools;

import model.Request;
import model.Response;
import model.Session;
import model.User;
import model.enums.EnumContentType;
import model.enums.EnumStatusCode;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

public class Utils {

    public static Response buildResponse(EnumContentType contentType) {
        switch (contentType) {
            case TEXT_PLAIN:
                return new Response(null, EnumContentType.TEXT_PLAIN.value, null, null, EnumStatusCode.SUCCESS.code);
            case TEXT_HTML:
                return new Response(null, EnumContentType.TEXT_HTML.value, null, null, EnumStatusCode.SUCCESS.code);
            case APPLICATION_JSON:
                return new Response(null, EnumContentType.APPLICATION_JSON.value, null, null, EnumStatusCode.SUCCESS.code);
            default:
                break;
        }
        return null;
    }

    public static String readHtmlFile(String name) {
        StringBuilder builder = new StringBuilder();
        try {
            BufferedInputStream bin = new BufferedInputStream(
                    Utils.class.getClassLoader().getResourceAsStream(
                            Constants.DIRECTORY_VIEWS + File.separator + name
                    )
            );
            byte[] contents = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = bin.read(contents)) != -1) builder.append(new String(contents, 0, bytesRead));
            bin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return builder.toString();
    }

    public static String decodeUrlParameter(String value) {
        try {
            return java.net.URLDecoder.decode(value, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Session generateSession(Request request, int userId) {
        String key = Session.generateSessionKey(request);
        Map<String, String> values = new LinkedHashMap<>();
        values.put(Session.SESSION_TOKEN, key);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.WEEK_OF_MONTH, 1);
        values.put(User.SESSION_USER_ID, String.valueOf(userId));
        values.put(Session.SESSION_EXPIRES, new SimpleDateFormat(Session.SESSION_EXPIRES_DATE_FORMAT).format(cal.getTime()).toString());
        values.put(Session.SESSION_PATH, File.separator +
                request.getUrl().getApplicationName() +
                File.separator +
                request.getUrl().getControllerName());
        Session session = new Session(key, values);
        return session;
    }
}
