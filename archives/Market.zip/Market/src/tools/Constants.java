package tools;

public class Constants {

    public static final String DIRECTORY_VIEWS = "web/html";
    public static final String FILE_INDEX = "index.html";
    public static final String FILE_LOGIN = "login.html";

}
