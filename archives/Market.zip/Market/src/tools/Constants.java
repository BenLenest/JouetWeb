package tools;

public class Constants {

    public static final String COOKIE_LOGGED_IN = "logged_in";
    public static final String DIRECTORY_VIEWS = "html";
    public static final String FILE_INDEX = "index.html";
    public static final String FILE_LOGIN = "login.html";

}
