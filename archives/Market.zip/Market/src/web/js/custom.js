var ajax;

$("a#subscribeLink").click(function(e) {
    $("div#loginDiv").hide();
    $("div#subscribeDiv").show();
    return false;
});

$("a#loginLink").click(function(e) {
    $("div#subscribeDiv").hide();
    $("div#loginDiv").show();
    return false;
});

$("form#ajaxLogin").submit(function(e) {

    e.preventDefault();

    var emailLogin = $("#emailLogin").val();
    var passwordLogin = $("#passwordLogin").val();

    if (ajax && ajax.readyState !== 4) { ajax.abort(); }

    ajax = $.ajax({
        type: "POST",
        url: "http://localhost:8080/market/games/login",
        async: false,
        timeout: 15000,
        dataType: "html",
        contentType: "text/html",
        data: { email : emailLogin, password : passwordLogin },
        success: function(data) {
            var returned = jQuery.parseJSON(data);
            if (returned.result == "true") {
                $("#loginFailure").hide();
                window.location.replace("http://localhost:8080/market/games/index");
            }
            else if (returned.result == "false") {
                $("#loginFailure").show();
            }
        }
    });

    return false;
});

$("form#ajaxSubscribe").submit(function(e) {

    e.preventDefault();

    var emailSubscribe = $("#emailSubscribe").val();
    var passwordSubscribe = $("#passwordSubscribe").val();

    if (ajax && ajax.readyState !== 4) { ajax.abort(); }

    ajax = $.ajax({
        type: "POST",
        url: "http://localhost:8080/market/games/subscribe",
        async: false,
        timeout: 15000,
        dataType: "html",
        contentType: "text/html",
        data: { email : emailSubscribe, password : passwordSubscribe },
        success: function(data) {
            var returned = jQuery.parseJSON(data);
            if (returned.result == "true") {
                $("#subscribeFailure").hide();
                window.location.replace("http://localhost:8080/market/games/index");
            }
            else if (returned.result == "false") {
                $("#subscribeFailure").show();
            }
        }
    });

    return false;
});

$("#logout").click(function(e) {

    if (ajax && ajax.readyState !== 4) { ajax.abort(); }

    ajax = $.ajax({
        type: "POST",
        url: "http://localhost:8080/market/games/logout",
        async: false,
        timeout : 15000,
        dataType: "html",
        contentType: "text/html",
        success: function(data) {
            window.location.replace("http://localhost:8080/market/games/login");
        }
    });

    return false;
});