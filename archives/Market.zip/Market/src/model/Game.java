package model;

public class Game {

    /* ATTRIBUTES ========================================================== */

    private int id;
    private String name;
    private int year;
    private String type;
    private String editor;
    private double price;
    private String description;

    /* CONSTRUCTOR ========================================================= */

    public Game(int id, String name, int year, String type, String editor, double price, String description) {
        this.id = id;
        this.name = name;
        this.year = year;
        this.type = type;
        this.editor = editor;
        this.price = price;
        this.description = description;
    }

/* SETTERS ============================================================= */

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /* GETTERS ============================================================= */

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getYear() {
        return year;
    }

    public String getType() {
        return type;
    }

    public String getEditor() {
        return editor;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }
}
