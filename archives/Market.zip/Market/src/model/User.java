package model;

public class User {

    /* CONSTANTS =========================================================== */

    public final static String SESSION_USER_ID = "id";

    /* ATTRIBUTES ========================================================== */

    private int id;
    private String email;
    private String password;

    /* CONSTRUCTOR ========================================================= */

    public User(int id, String email, String password) {
        this.id = id;
        this.email = email;
        this.password = password;
    }

    /* SETTERS ============================================================= */

    public void setId(int id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /* GETTERS ============================================================= */

    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
