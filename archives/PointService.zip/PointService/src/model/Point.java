package model;

public class Point {

    /* ATTRIBUTES ========================================================== */

    private int id;
    private double x;
    private double y;

    /* CONSTRUCTOR ========================================================== */

    public Point(int id, double x, double y) {
        this.id = id;
        this.x = x;
        this.y = y;
    }

    /* SETTERS ============================================================== */

    public void setId(int id) {
        this.id = id;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    /* GETTERS ============================================================== */

    public int getId() {
        return id;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    /* PUBLIC METHODS ======================================================== */

    public void updateCoordinates(double x, double y) {
        this.x = x;
        this.y = y;
    }
}
