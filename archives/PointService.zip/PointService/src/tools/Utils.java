package tools;

import model.Response;
import model.enums.EnumContentType;
import model.enums.EnumStatusCode;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

public class Utils {

    public static Response buildResponse(EnumContentType contentType) {
        switch (contentType) {
            case TEXT_PLAIN:
                return new Response(null, EnumContentType.TEXT_PLAIN.value, null, EnumStatusCode.SUCCESS.code);
            case TEXT_HTML:
                return new Response(null, EnumContentType.TEXT_HTML.value, null, EnumStatusCode.SUCCESS.code);
            case APPLICATION_JSON:
                return new Response(null, EnumContentType.APPLICATION_JSON.value, null, EnumStatusCode.SUCCESS.code);
            default:
                break;
        }
        return null;
    }

    public static JSONObject buildJsonArray(String key, Map<String, Object> entries) {
        JSONObject jsonObject = new JSONObject();
        for (Map.Entry entry : entries.entrySet())
            jsonObject.put(entry.getKey().toString(), entry.getValue().toString());
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonObject);
        JSONObject jsonReturn = new JSONObject();
        jsonReturn.put(key, jsonArray);
        return jsonReturn;
    }

    public static JSONObject buildJsonList(String key, List values) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(key, values);
        JSONArray jsonArray = jsonObject.getJSONArray(key);
        JSONObject jsonReturn = new JSONObject();
        jsonReturn.put(key, jsonArray);
        return jsonReturn;
    }
}
