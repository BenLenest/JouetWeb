package manager;

import model.Point;
import model.Request;
import model.Response;
import model.enums.EnumContentType;
import org.json.JSONObject;
import tools.Utils;

import java.util.ArrayList;
import java.util.List;

public class ResourcesController {

    /* DATABASE (simulation) =============================================== */

    private static int idCounter = 5;
    private static List<Point> points = new ArrayList<Point>() {{
        add(new Point(0, 3, 6));
        add(new Point(1, 5, 2));
        add(new Point(2, 12, 7));
        add(new Point(3, 9, 2));
        add(new Point(4, 2, 2));
    }};

    /* GET METHODS ========================================================= */

    public static Response getPointsIds(Request request) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        List ids = new ArrayList<>();
        for (int i = 0 ; i < points.size() ; i++) ids.add(points.get(i).getId());
        response.setContent(Utils.buildJsonList("ids", ids).toString());
        return Utils.buildResponseWithSession(response, request.getSession());
    }

    public static Response getXByPointId(Request request, int id) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        JSONObject jsonObject = new JSONObject();
        for (Point pt : points) if (pt.getId() == id) jsonObject.put("X", pt.getX());
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, request.getSession());
    }

    public static Response getYByPointId(Request request, int id) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        JSONObject jsonObject = new JSONObject();
        for (Point pt : points) if (pt.getId() == id) jsonObject.put("Y", pt.getY());
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, request.getSession());
    }

    /* PUT METHODS ========================================================= */

    public static Response updatePointById(Request request, int id, double x, double y) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        JSONObject jsonObject = new JSONObject();
        boolean updated = false;
        for (Point pt : points)
            if (pt.getId() == id) {
                pt.updateCoordinates(x, y);
                updated = true;
                break;
            }
        jsonObject.put("updated", updated);
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, request.getSession());
    }

    /* POST METHODS ======================================================== */

    public static Response addPoint(Request request, double x, double y) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        JSONObject jsonObject = new JSONObject();
        points.add(new Point(idCounter, x, y));
        jsonObject.put("added", idCounter++);
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, request.getSession());
    }

    /* DELETE METHODS ====================================================== */

    public static Response removePointById(Request request, int id) {
        Response response = Utils.buildResponse(EnumContentType.APPLICATION_JSON);
        JSONObject jsonObject = new JSONObject();
        boolean removed = false;
        for (Point pt : points) if (pt.getId() == id) { points.remove(pt); removed = true; break; }
        jsonObject.put("removed", removed);
        response.setContent(jsonObject.toString());
        return Utils.buildResponseWithSession(response, request.getSession());
    }
}
